for loop1=1
filename = strcat('Limestone','.mat')
load(filename)
figure
histogram(filename)
end