function [tcalc,ttabulated,signif]=t_test(x,y,pvalue)
if nargin < 3
    pvalue=0.05;
end
Nx = numElements(x)
Ny = numElements(y)
stdX = std(x)
stdY = std(y)
meanX = mean(x)
meanY = mean(y)
stdErrorX = stdX/(Nx^2)
stdErrorY = stdY/(Ny^2)
stdDiff = (stdErrorX^2 + stdErrorY^2)^0.5
meandiff = abs(meanX - meanY)
tcalc = meandiff/ stdDiff
cumulatedpvalue = 1-(pvalue/2)
a = (stdErrorX^2 + stdErrorY^2)^2
b = (stdX^4/ (Nx^3-Nx^4)) + (stdY^4/ (Ny^3-Ny^4))
df = a/b
ttabulated = tinv(cumulatedpvalue,df)
if tcalc > ttabulated
    signif = 1
else
    signif = 0
end
end