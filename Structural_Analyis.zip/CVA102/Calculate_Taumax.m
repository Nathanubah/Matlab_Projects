function [t_max bv] = Calculate_Taumax(w,r,T,p) % This identifies a function 
ratio = r./w;                   %% This calculates the ratio d/b to calculate the coefficients
coefficient_ratio = [1.0, 1.2, 1.5, 2.0, 2.5,3.0, 4.0, 5.0, 6.0]; %% This is the coefficient ratio for the corresponding alpha values
alpha_values_table = [0.208, 0.219, 0.231, 0.246, 0.258,0.267, 0.282, 0.291, 0.299]; %% These are the coefficients for alpha
alpha_values = interp1(coefficient_ratio,alpha_values_table,ratio);    %% This calculates all the alpha values
J = alpha_values.*r.*(w.^3);     %% This calculates the J-alpha values
t = (T.*w)./J;              %% This calculates the max shear stress due to tosion, units = kN/m^2
t_max = (t+p)./1000;    %% This calculates the total maximum shear stress in the beam, units = MPa
bv = t
end