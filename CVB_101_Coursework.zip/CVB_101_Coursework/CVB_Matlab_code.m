%% Question 2
%% Program setup 
clear();
clc();
close all;
water_density = 1000;
sedement_density = 2700; % Paper given says = 2650kg/m3
med_grain = 1.6e-3; % median grain 
shields_crit = 0.045; % Critical shields parameter

%% Import Mat files into array of structs
% File names
files = dir("*.mat"); % Scan working directory for all mat files

% Preallocate memory
stations = struct;
suspended_stations = 0;

% Allocate each file ina struct
for i = 1:length(files)
    file = files(i).name;
    load(file,"data"); % Load mat file
    stations(i).times = data(:,1); % Time / s
    % Store location of each station
    coord = files(i).name(2:5); % Extract coordinates from the file name
    stations(i).x_coord = str2double(coord(1:2)); % 1st 2 characters are x
    stations(i).y_coord = str2double(coord(3:4)); % 2nd 2 characters are y
    % Convert all velocites to m/s 
    stations(i).i = data(:,2)*0.01; % Longditudinal velocity 
    stations(i).j = data(:,4)*0.01; % Vertical velocity 
    stations(i).k = data(:,3)*0.01; % Transverse 
end

%% Calculate reynolds stress
for i = 1:length(stations)
    % Avaerage time for each direction
    stations(i).ave_i = mean(stations(i).i);
    stations(i).ave_j = mean(stations(i).j);
    stations(i).ave_k = mean(stations(i).k);

    % Calculate the deviator velocities
    stations(i).dev_i = stations(i).i - stations(i).ave_i;
    stations(i).dev_j = stations(i).j - stations(i).ave_j;
    stations(i).dev_k = stations(i).k - stations(i).ave_k;
    
    stations(i).vel_product = stations(i).dev_i.*stations(i).dev_j; % Product of i and j 
    
    stations(i).ave_dev = mean(stations(i).vel_product); % Average time for all of the deviator products
    
    stations(i).reynolds_stress = -1*water_density*stations(i).ave_dev; % Reynolds stress
    
    % Calculate Sheild's parametre
    stations(i).sheilds = stations(i).reynolds_stress/((sedement_density-water_density)*9.8*med_grain);
    
    % Check for suspended sediment
    if (abs(stations(i).sheilds) > shields_crit) % Suspended if above crit sheilds
        stations(i).is_suspended = true;
        suspended_stations = suspended_stations + 1;
    else
        stations(i).is_suspended = false;
    end
end
% Display suspended stations
% Create variables
suspended_x = zeros(1,suspended_stations);
suspended_y = zeros(1,suspended_stations);
stations_x = zeros(1,length(stations));
stations_y = zeros(1,length(stations));

% Add the suspended stations to suspended list
coordinates = 1;
for i = 1:length(stations)
    if stations(i).is_suspended
        suspended_x(coordinates) = stations(i).x_coord;
        suspended_y(coordinates) = stations(i).y_coord;
        coordinates = coordinates + 1;
    end
    % List of stations
    stations_x(i) = stations(i).x_coord;
    stations_y(i) = stations(i).y_coord;
end

% Draw top down view
figure();
hold on;
scatter(stations_x,stations_y,"x","b"); % Plot all stations
scatter(suspended_x,suspended_y,"x","r"); % Overwrite staitons green if the sediment is suspended
xlabel("Stations: red cross are suspended sediments");
station_names = cellstr(num2str((1:25)'));
text(stations_x,stations_y,station_names);


x = linspace(0,50,50);
y1 = 0*x;
plot(x,y1,Color="black"); % Bottom wall of flume
y2 = y1 + 14.8;
plot(x,y2,"--",Color="black"); % Partition of flume
y3 = y1 + 30.5;
plot(x,y3,Color="black"); % Top wall of flume
hold off

%% Question 3, calculate reynolds stress
figure;
for i = 1:length(stations)
    % Time avaerage each direction
    stations(i).average_i = mean(stations(i).i);
    stations(i).average_j = mean(stations(i).j);
    stations(i).average_k = mean(stations(i).k);
    
    % Calculate the deviator velocities
    stations(i).deviation_i = stations(i).i - stations(i).average_i;
    stations(i).deviation_j = stations(i).j - stations(i).average_j;
    stations(i).deviation_k = stations(i).k - stations(i).average_k;

    % Plot vertical deviatior against longditiudinal for each station
    subplot(5,5,i);
    scatter(stations(i).deviation_i,stations(i).j);
    xlabel("u_i"); ylabel("u_j"); title(sprintf("Station %d",i));
    hold on;
    x = linspace(-0.35,0.35,10);
    y = 0*x;
    % Draw axis baselines
    plot(x,y,'Color','blue');
    plot(y,x,'Color','blue');

    
    % Calculate maximum values for each quadrant by using pythagoras 
    stations(i).outwards = []; stations(i).outwards_pair.i = []; stations(i).outwards_pair.j = [];
    stations(i).ejections = []; stations(i).ejections_pair.i = []; stations(i).ejections_pair.j = [];
    stations(i).inwards = []; stations(i).inwards_pair.i = []; stations(i).inwards_pair.j = [];
    stations(i).sweeps = []; stations(i).sweeps_pair.i = []; stations(i).sweeps_pair.j = [];
    for time_i = 1:length(stations(i).times) 
        if stations(i).deviation_i(time_i) > 0 && stations(i).deviation_j(time_i) > 0 % Quadrant 1
            stations(i).outwards(end+1) = sqrt(stations(i).deviation_i(time_i)^2 + stations(i).deviation_j(time_i)^2); % Modulus of deviation
            stations(i).outwards_pair(end+1).i = stations(i).deviation_i(time_i); % i values
            stations(i).outwards_pair(end).j = stations(i).deviation_j(time_i); % j values 
        elseif stations(i).deviation_i(time_i) < 0 && stations(i).deviation_j(time_i) > 0 % Quadrant 2
            stations(i).ejections(end+1) = sqrt(stations(i).deviation_i(time_i)^2 + stations(i).deviation_j(time_i)^2);  % Modulus of deviation
            stations(i).ejections_pair(end+1).i = stations(i).deviation_i(time_i); % i values
            stations(i).ejections_pair(end).j = stations(i).deviation_j(time_i); % j values
        elseif stations(i).deviation_i(time_i) < 0 && stations(i).deviation_j(time_i) < 0 % Quadrant 3
            stations(i).inwards(end+1) = sqrt(stations(i).deviation_i(time_i)^2 + stations(i).deviation_j(time_i)^2);  % Modulus of deviation
            stations(i).inwards_pair(end+1).i = stations(i).deviation_i(time_i); % i values
            stations(i).inwards_pair(end).j = stations(i).deviation_j(time_i);  % j values
        else % Quadrant 4
            stations(i).sweeps(end+1) = sqrt(stations(i).deviation_i(time_i)^2 + stations(i).deviation_j(time_i)^2);  % Modulus of deviation
            stations(i).sweeps_pair(end+1).i = stations(i).deviation_i(time_i); % i values
            stations(i).sweeps_pair(end).j = stations(i).deviation_j(time_i); % j values
        end
    end

    % Remove any empty values from list
    stations(i).outwards_pair = stations(i).outwards_pair(2:length(stations(i).outwards_pair));
    stations(i).ejections_pair = stations(i).ejections_pair(2:length(stations(i).ejections_pair));
    stations(i).inwards_pair = stations(i).inwards_pair(2:length(stations(i).inwards_pair));
    stations(i).sweeps_pair = stations(i).sweeps_pair(2:length(stations(i).sweeps_pair));
    
    % Find the maximum value for each quadrant
    stations(i).max_outward = max(stations(i).outwards);
    stations(i).max_ejection = max(stations(i).ejections);
    stations(i).max_inward = max(stations(i).inwards);
    stations(i).max_sweep = max(stations(i).sweeps);
        
    % Find the location of the maximum value in list
    outward_index = find(stations(i).outwards == stations(i).max_outward);
    ejection_index = find(stations(i).ejections == stations(i).max_ejection);
    inward_index = find(stations(i).inwards == stations(i).max_inward);
    sweep_index = find(stations(i).sweeps == stations(i).max_sweep);

    % Calculate the instantanious stress value
    stations(i).outward_stress = -1 * water_density * stations(i).outwards_pair(outward_index).i * stations(i).outwards_pair(outward_index).j;
    stations(i).ejection_stress = -1 * water_density * stations(i).ejections_pair(ejection_index).i * stations(i).ejections_pair(ejection_index).j;
    stations(i).inward_stress = -1 * water_density * stations(i).inwards_pair(inward_index).i * stations(i).inwards_pair(inward_index).j;
    stations(i).sweep_stress = -1 * water_density * stations(i).sweeps_pair(sweep_index).i * stations(i).sweeps_pair(sweep_index).j;

    % Calculate the sheilds parameter for the instant stress values
    stations(i).outward_shield = abs(stations(i).outward_stress / ((sedement_density - water_density) * 9.8 * med_grain));
    stations(i).ejection_shield = abs(stations(i).ejection_stress / ((sedement_density - water_density) * 9.8 * med_grain));
    stations(i).inward_shield = abs(stations(i).inward_stress / ((sedement_density - water_density) * 9.8 * med_grain));
    stations(i).sweep_shield = abs(stations(i).sweep_stress / ((sedement_density - water_density) * 9.8 * med_grain));

    % Check if station is entrained for each quadrant
    if stations(i).outward_shield > shields_crit
        stations(i).outward_suspend = true;
    else
        stations(i).outward_suspend = false;
    end
    if stations(i).ejection_shield > shields_crit
        stations(i).ejection_suspend = true;
    else
        stations(i).ejection_sus = false;
    end
    if stations(i).inward_shield > shields_crit
        stations(i).inward_suspend = true;
    else
        stations(i).inward_suspend = false;
    end
    if stations(i).sweep_shield > shields_crit
        stations(i).sweep_suspend = true;
    else
        stations(i).sweep_suspend = false;
    end
    

    % Assess if stations are suspended
    % Only consider Quadrant 1 (outward), 4 (sweep)
    if stations(i).sweep_suspend || stations(i).outward_suspend
        stations(i).is_suspended = true;
    else
        stations(i).is_suspended = false;
    end
end

    % Display suspended stations
    % Preallocate memory
    suspended_x = zeros(1, suspended_stations);
    suspended_y = zeros(1, suspended_stations);
    stations_x = zeros(1, length(stations));
    stations_y = zeros(1, length(stations));

    % Run 2 parallel for loops
    coordinate_index = 1;
    for i = 1:length(stations)
        if stations(i).is_suspended
            % Add station to suspended list
            suspended_x(coordinate_index) = stations(i).x_coord;
            suspended_y(coordinate_index) = stations(i).y_coord;
            coordinate_index = coordinate_index + 1;
        end
        % Add station to list of stations
        stations_x(i) = stations(i).x_coord;
        stations_y(i) = stations(i).y_coord;
    end

    % Draw top down view
    figure();
    hold on;
    scatter(stations_x, stations_y, [], "red"); % Plot all stations
    scatter(suspended_x, suspended_y, [], "blue"); % It will show blue if suspennded
    xlabel("Circles are stations: Blue = suspended sediment");

    x = linspace(0, 50, 50);
    y1 = 0*x;
    plot(x, y1, 'k'); % Bottom wall of flume
    y2 = y1 + 14.8;
    plot(x, y2, 'k'); % Partition of flume
    y3 = y1 + 30.5;
    plot(x, y3, 'k'); % Top wall of flume
    station_names = num2str((1:25)');
    text(stations_x, stations_y, station_names);
    hold off
    

%% Question 4
crit_shear = 4; % Decided from observising snapshot figure
crit_force = crit_shear*exposed_A(); % shear stress multiplied by force
interval = 0.04; % Time interval

% Calculate reynolds stress
for index = 1:length(stations)
    % Time avaerage each direction
    stations(index).ave_i = mean(stations(index).i);
    stations(index).ave_j = mean(stations(index).j);
    stations(index).ave_k = mean(stations(index).k);
    
    % Calculate the deviator velocities
    stations(index).deviation_i = stations(index).i - stations(index).ave_i;
    stations(index).deviation_j = stations(index).j - stations(index).ave_j;
    stations(index).deviation_k = stations(index).k - stations(index).ave_k;
    
    stations(index).ii_stress = abs(1*water_density*stations(index).deviation_i.*stations(index).deviation_i); % u^2
    stations(index).ij_stress = abs(1*water_density*stations(index).deviation_i.*stations(index).deviation_j); % boundary layer from previous questions
    stations(index).ik_stress = abs(1*water_density*stations(index).deviation_i.*stations(index).deviation_k); % Resolve u and w for the boundary layer
        
    % Adjust data to origin using critical force
    stations(index).direction = [];
    stations(index).direction(1).ij_reduced = stations(index).ii_stress - crit_force;
    stations(index).direction(2).ij_reduced = stations(index).ij_stress - crit_force;
    stations(index).direction(3).ij_reduced = stations(index).ik_stress - crit_force;
    
    for i = 1:length(stations(index).direction)
        % Find all the points of intersection between x axis and data, then interpolate missing points
        [stations(index).direction(i).x_intersects,stations(index).direction(i).y_intersects] = polyxpoly(stations(index).times,stations(index).direction(i).ij_reduced,linspace(0,max(stations(index).times)),linspace(0,max(stations(index).times))*0);
        
        % Add an psuedo starting intersection
        if stations(index).direction(i).ij_reduced(1) > 0
            stations(index).direction(i).x_intersects = [stations(index).times(1);stations(index).direction(i).x_intersects];
            stations(index).direction(i).y_intersects = [stations(index).direction(i).ij_reduced(1);stations(index).direction(i).y_intersects];
        end
        if stations(index).direction(i).ij_reduced(end) > 0
            stations(index).direction(i).x_intersects = [stations(index).direction(i).x_intersects;stations(index).times(end)];
            stations(index).direction(i).y_intersects = [stations(index).direction(i).y_intersects;stations(index).direction(i).ij_reduced(end)];
        end
        
        % Add the intersection points to the initial dataset
        stations(index).direction(i).times = [stations(index).times; stations(index).direction(i).x_intersects];
        stations(index).direction(i).ij_reduced = [stations(index).direction(i).ij_reduced; stations(index).direction(i).y_intersects];
        
        % Sort data again based on time
        [stations(index).direction(i).times,foo] = sort(stations(index).direction(i).times);
        stations(index).direction(i).ij_reduced = stations(index).direction(i).ij_reduced(foo); clear foo;
        
        % Integrate each section and place to areas
        stations(index).direction(i).areas = [];
        integrate_points = [];
        for time_i = 1:length(stations(index).direction(i).times)
            % If above F_crit then add area to the current integral sum
            if (stations(index).direction(i).ij_reduced(time_i) >= 0 && time_i ~= length(stations(index).direction(i).times))
                integrate_points(end+1) = time_i;
            elseif isempty(integrate_points) % Does nothing if below F_crit
            % If at the end of the integral, then sum all areas to 1 event
            else
                bar.x = stations(index).direction(i).times(integrate_points);
                bar.y = stations(index).direction(i).ij_reduced(integrate_points);
                stations(index).direction(i).areas(end+1) = trapz(bar.x,bar.y);
                integrate_points = []; % clears list for new event
            end
        end
        stations(index).direction(i).impulses = stations(index).direction(i).areas*exposed_A(med_grain); % Converts stress to a force
        time_above_zero = sum(stations(index).direction(i).ij_reduced>0); % Find out how much time is spent experinecing events
        stations(index).direction(i).prob = 100*time_above_zero/length(stations(index).direction(i).ij_reduced); % Calculate proportion of whole time
        clear bar; 
    end
    % It was chosen to utilize the resolved boundary layer for impulses
    stations(index).prob = stations(index).direction(3).prob;
end

% Plotting probability of impulses
for qox = 1
    % Preallocate memory
    stations_x = zeros(length(stations),1);
    stations_y = zeros(length(stations),1);
    stations_impulse = zeros(length(stations),1);
    
    for index = 1:length(stations)
        stations_x(index) = stations(index).x_coord;
        stations_y(index) = stations(index).y_coord;
        stations_impulse(index) = stations(index).prob;
    end
    
    figure();
    hold on;
    % Linearly interpolate the percentage of time while expereiencing impulse events
    interp = scatteredInterpolant(stations_x,stations_y,stations_impulse,"linear","none"); % Prevent extrapolation 
    [xx,yy] = meshgrid(linspace(0,60),linspace(0,30.5));     % Create a coordinate grid 
    % Interpolate intensity for each grid value
    intensit_interp = interp(xx,yy); 
    % Plot contour map of flume
    [foo,bar] = contourf(xx,yy,intensit_interp,(0:5:50));
    clabel(foo,bar);
    % Plot station locations and boundary lines
    scatter(stations_x,stations_y,[],"yellow");
    boundary_x = linspace(0,55); boundary_y = 0*boundary_x;
    plot(boundary_x,boundary_y,Color="black"); boundary_y = 0*boundary_x + 14.8;
    plot(boundary_x,boundary_y,"--",Color="black"); boundary_y = 0*boundary_x + 30.5;
    plot(boundary_x,boundary_y,Color="black");
    text(stations_x,stations_y + 1,num2str((1:25)'));
    hold off;    
end
clear foo bar; % Clean up after placeholder variables

% Plotting Snapshot - Used to decide the value of F_crit
% View first 50 points of data to analyse small events
snap_length = 50;
plot_stations = [6,10,18,24]; % Use a variety of stations to look at events
direction_names = ["ii", "ij","ik"];
stations = stations(plot_stations);

% Plot each type of stress for each station
figure();
for foo = 1:length(plot_stations)
    for bar = 1:3
        subplot(4,3,(3*(foo - 1) + bar));
        plot(stations(foo).direction(bar).times(1:snap_length),stations(foo).direction(bar).ij_reduced(1:snap_length));
        hold on;
        x = linspace(0,stations(foo).direction(bar).times(snap_length),snap_length); y = x*0;
        plot(x,y,Color="black");
        title(sprintf("Station %d",plot_stations(foo)));
        xlabel(sprintf("%s",direction_names(bar)));
    end
end
clear foo bar; % Clean up after placeholder variables