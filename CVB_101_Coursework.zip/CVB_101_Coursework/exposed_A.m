function exposed_Area = exposed_A(grain_diametre,bed_diametre)
arguments %% Create default arguemnts
    grain_diametre = 1.6; % In mm
    bed_diametre = 2.36; % In mm
end
%% Setup variables
bed_radius = bed_diametre/2; grain_radius = grain_diametre/2; % Convert diametres to radii

%% Calucate Angles
bed_slope = bed_radius/(bed_radius + grain_radius);
bed_elevation = acos(bed_slope);

grain_zenith = pi/2 - bed_elevation; % There are 90 degrees in a right-angle

%% Calculate Areas
area_of_circle = pi*grain_radius^2; % pi*r^2
area_of_sector = grain_zenith*grain_radius^2; % theta/2*r^2
area_of_triangle = sin(2*grain_zenith)/2*grain_radius^2; % 0.5*a*b*sin(theta)
area_of_segment = area_of_sector - area_of_triangle;
exposed_Area = area_of_circle - area_of_segment;





